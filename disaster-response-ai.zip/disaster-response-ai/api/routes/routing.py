from fastapi import APIRouter
from core.routing.maps_integration import GoogleMapsClient
from core.routing.danger_zones import DangerZoneManager

router = APIRouter()
gmaps = GoogleMapsClient()
danger_zones = DangerZoneManager()

@router.get("/safe_route")
async def get_safe_route(start: str, end: str):
    route = gmaps.get_route(start, end)
    safe_route = danger_zones.avoid_danger(route)
    return {"original": route, "optimized": safe_route}