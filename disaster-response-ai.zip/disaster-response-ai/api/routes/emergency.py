from fastapi import APIRouter, HTTPException
from schemas.emergency import EmergencyReport
from core.nlp.social_monitor import analyze_social_media
from core.nlp.anomaly_detector import check_sensor_anomalies
import redis

router = APIRouter()
r = redis.Redis(host="redis", port=6379, db=0)

@router.post("/detect")
async def detect_emergency(report: EmergencyReport):
    try:
        social_result = analyze_social_media(report.text)
        sensor_result = check_sensor_anomalies(report.location)
        
        if social_result["confidence"] > 0.8 or sensor_result["is_anomalous"]:
            r.geoadd("active_emergencies", report.location.lon, report.location.lat, report.id)
            return {"status": "reported", "id": report.id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))