from fastapi import APIRouter
from core.satellite.nasa_api import get_fire_data
from core.satellite.imagery_processor import SatelliteProcessor

router = APIRouter()
satellite = SatelliteProcessor()

@router.get("/predict/flood")
async def predict_flood(lat: float, lon: float):
    return {"risk": satellite.predict_flood(lat, lon)}

@router.get("/predict/fire")
async def predict_fire():
    return get_fire_data()  # NASA FIRMS