from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List
import numpy as np
from sklearn.ensemble import RandomForestRegressor

router = APIRouter()

class AidRequest(BaseModel):
    location: tuple[float, float]  # (lat, lon)
    population: int
    infrastructure_damage: float  # 0-1 scale

# Pretrained model (loads from /models/aid_model.joblib)
aid_model = RandomForestRegressor()  
aid_model.load("models/aid_model.joblib")  # Pre-trained on historical disaster data

@router.post("/optimize")
async def optimize_aid(requests: List[AidRequest]):
    try:
        X = np.array([[req.population, req.infrastructure_damage] for req in requests])
        priorities = aid_model.predict(X)  # Returns priority scores (0-100)
        return {
            "priorities": priorities.tolist(),
            "recommended_allocation": np.argsort(-priorities).tolist()  # Descending
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))