from fastapi import APIRouter, HTTPException
import shap
import numpy as np
import joblib
from typing import Dict, Any
from schemas.prediction import ExplanationResponse

router = APIRouter()

# Load pre-trained model and explainer
MODEL = joblib.load("models/aid_priority_model.joblib")
EXPLAINER = shap.TreeExplainer(MODEL)

@router.post("/explain", response_model=ExplanationResponse)
async def explain_prediction(input_data: Dict[str, Any]):
    """
    Generates SHAP explanations for model predictions.
    Example input: {"features": [population, damage_score], "feature_names": ["population", "damage"]}
    """
    try:
        features = np.array([input_data["features"]])
        shap_values = EXPLAINER.shap_values(features)
        
        return {
            "prediction": float(MODEL.predict(features)[0]),
            "shap_values": shap_values[0].tolist(),
            "base_value": float(EXPLAINER.expected_value),
            "feature_importance": {
                name: abs(val) for name, val in zip(
                    input_data["feature_names"],
                    shap_values[0]
                )
            }
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))