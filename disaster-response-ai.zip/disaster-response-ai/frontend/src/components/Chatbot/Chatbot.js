import React, { useState, useEffect } from 'react';
import { useSpeechRecognition, useSpeechSynthesis } from 'react-speech-kit';
import { Box, Card, CardContent, Typography, TextField, IconButton, List, ListItem, ListItemText, Avatar, CircularProgress } from '@mui/material';
import { Mic, Send, Language, Headset } from '@mui/icons-material';

const ChatBot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [language, setLanguage] = useState('en');
  
  const { listen, listening, stop } = useSpeechRecognition({
    onResult: (result) => setInput(result),
  });
  
  const { speak, speaking } = useSpeechSynthesis();

  const handleSend = () => {
    if (!input.trim()) return;
    
    const userMessage = { text: input, sender: 'user' };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);
    
    // Simulate bot response
    setTimeout(() => {
      const responses = {
        en: `I've logged your report about "${input}". Help is on the way.`,
        es: `He registrado tu informe sobre "${input}". La ayuda está en camino.`,
        fr: `J'ai enregistré votre rapport concernant "${input}". L'aide est en route.`
      };
      
      const botMessage = { 
        text: responses[language] || responses.en, 
        sender: 'bot' 
      };
      
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
      speak({ text: botMessage.text, lang: language });
    }, 1500);
  };

  return (
    <Card sx={{ maxWidth: 500, margin: 'auto', mt: 4 }}>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Headset color="primary" sx={{ mr: 1 }} />
          <Typography variant="h5">Emergency Assistant</Typography>
          <Box sx={{ flexGrow: 1 }} />
          <IconButton onClick={() => setLanguage(lang => lang === 'en' ? 'es' : lang === 'es' ? 'fr' : 'en')}>
            <Language />
          </IconButton>
          <Typography variant="caption" sx={{ ml: 1 }}>
            {language.toUpperCase()}
          </Typography>
        </Box>
        
        <Box sx={{ height: 300, overflowY: 'auto', mb: 2, p: 1, border: '1px solid #eee', borderRadius: 1 }}>
          <List>
            {messages.map((msg, index) => (
              <ListItem key={index} sx={{ 
                justifyContent: msg.sender === 'user' ? 'flex-end' : 'flex-start',
                alignItems: 'flex-start'
              }}>
                {msg.sender === 'bot' && (
                  <Avatar sx={{ bgcolor: 'primary.main', mr: 1 }}>
                    <Headset />
                  </Avatar>
                )}
                <ListItemText
                  primary={msg.text}
                  sx={{
                    bgcolor: msg.sender === 'user' ? 'primary.light' : 'background.paper',
                    p: 1.5,
                    borderRadius: 2,
                    maxWidth: '70%',
                    boxShadow: 1
                  }}
                />
              </ListItem>
            ))}
            {isTyping && (
              <ListItem>
                <Avatar sx={{ bgcolor: 'primary.main', mr: 1 }}>
                  <Headset />
                </Avatar>
                <CircularProgress size={24} />
              </ListItem>
            )}
          </List>
        </Box>
        
        <Box sx={{ display: 'flex', gap: 1 }}>
          <TextField
            fullWidth
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your emergency..."
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            aria-label="Chat input"
          />
          <IconButton
            onClick={listening ? stop : listen}
            color={listening ? 'error' : 'default'}
            aria-label={listening ? 'Stop recording' : 'Start voice recording'}
          >
            <Mic />
          </IconButton>
          <IconButton
            onClick={handleSend}
            disabled={!input.trim()}
            color="primary"
            aria-label="Send message"
          >
            <Send />
          </IconButton>
        </Box>
      </CardContent>
    </Card>
  );
};

export default ChatBot;