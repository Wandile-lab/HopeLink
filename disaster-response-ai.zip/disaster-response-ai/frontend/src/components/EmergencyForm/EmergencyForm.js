import React, { useState } from 'react';
import { useSpeechRecognition } from 'react-speech-kit';
import { Button, TextField, Card, CardContent, Typography, Box, CircularProgress } from '@mui/material';
import { CameraAlt, Mic, Send, LocationOn } from '@mui/icons-material';

const EmergencyForm = () => {
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [photo, setPhoto] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { listen, listening, stop } = useSpeechRecognition({
    onResult: (result) => setDescription(result),
  });

  const handlePhotoUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    setIsSubmitting(true);
    // Submit logic here
  };

  return (
    <Card elevation={3} sx={{ maxWidth: 500, margin: 'auto', mt: 4 }}>
      <CardContent>
        <Typography variant="h5" gutterBottom>
          Report Emergency
        </Typography>
        
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <LocationOn color="primary" />
          <TextField
            fullWidth
            label="Location"
            variant="outlined"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            aria-label="Emergency location"
          />
        </Box>

        <Box sx={{ mb: 2 }}>
          <TextField
            fullWidth
            multiline
            rows={3}
            label="Description"
            variant="outlined"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            aria-label="Emergency description"
          />
          <Button
            startIcon={<Mic />}
            onClick={listening ? stop : listen}
            sx={{ mt: 1 }}
            aria-label={listening ? 'Stop recording' : 'Start voice recording'}
          >
            {listening ? 'Stop Recording' : 'Voice Input'}
          </Button>
        </Box>

        <Box sx={{ mb: 3 }}>
          <input
            accept="image/*"
            style={{ display: 'none' }}
            id="photo-upload"
            type="file"
            onChange={handlePhotoUpload}
          />
          <label htmlFor="photo-upload">
            <Button
              variant="outlined"
              component="span"
              startIcon={<CameraAlt />}
              fullWidth
            >
              Upload Photo
            </Button>
          </label>
          {photo && (
            <Box sx={{ mt: 2 }}>
              <img src={photo} alt="Emergency preview" style={{ maxWidth: '100%', maxHeight: 200 }} />
            </Box>
          )}
        </Box>

        <Button
          variant="contained"
          color="primary"
          fullWidth
          size="large"
          startIcon={isSubmitting ? <CircularProgress size={20} color="inherit" /> : <Send />}
          onClick={handleSubmit}
          disabled={isSubmitting}
          aria-busy={isSubmitting}
        >
          {isSubmitting ? 'Submitting...' : 'Submit Report'}
        </Button>
      </CardContent>
    </Card>
  );
};

export default EmergencyForm;