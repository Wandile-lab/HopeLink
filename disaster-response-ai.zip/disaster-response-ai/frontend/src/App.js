import React from 'react';
import { ThemeProvider, CssBaseline } from '@mui/material';
import EmergencyForm from './components/EmergencyForm';
import DisasterMap from './components/DisasterMap';
import RoutePanel from './components/RoutePanel';
import AidDashboard from './components/AidDashboard';
import ChatBot from './components/ChatBot';
import theme from './styles/theme';
import OfflineBanner from './components/OfflineBanner';

const sampleIncidents = [
  { lat: 51.505, lng: -0.09, type: 'Flood', description: 'Major flooding in downtown area' },
  { lat: 51.51, lng: -0.1, type: 'Fire', description: 'Building fire reported' },
];

const sampleRoutes = [
  {
    type: 'walking',
    distance: '1.2',
    duration: '15 mins',
    summary: 'Safest pedestrian route',
    time: '15:45',
    warnings: ['Avoid Main St bridge']
  },
  {
    type: 'driving',
    distance: '3.5',
    duration: '8 mins',
    summary: 'Fastest vehicle route',
    time: '15:38',
    warnings: ['Heavy traffic on Oak Ave']
  }
];

const sampleAidData = {
  resources: [
    { name: 'Food', value: 400 },
    { name: 'Water', value: 300 },
    { name: 'Medicines', value: 300 },
    { name: 'Blankets', value: 200 },
  ],
  priorityAreas: [
    { name: 'Downtown', severity: 8 },
    { name: 'Northside', severity: 5 },
    { name: 'West End', severity: 3 },
    { name: 'East Village', severity: 6 },
  ]
};

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ p: 3, maxWidth: 1200, margin: 'auto' }}>
        <OfflineBanner />
        
        <Typography variant="h3" gutterBottom sx={{ mb: 4, fontWeight: 'bold' }}>
          Disaster Response System
        </Typography>
        
        <Grid container spacing={4}>
          <Grid item xs={12} md={6}>
            <EmergencyForm />
          </Grid>
          <Grid item xs={12} md={6}>
            <DisasterMap incidents={sampleIncidents} />
          </Grid>
          <Grid item xs={12} md={4}>
            <RoutePanel routes={sampleRoutes} />
          </Grid>
          <Grid item xs={12} md={8}>
            <AidDashboard data={sampleAidData} />
          </Grid>
          <Grid item xs={12}>
            <ChatBot />
          </Grid>
        </Grid>
      </Box>
    </ThemeProvider>
  );
}

function FileStatusChecker() {
  const [files, setFiles] = useState([
    '/favicons/favicon.ico',
    '/manifest.json',
    '/favicons/android-chrome-192x192.png'
  ]);

  const checkFile = async (path) => {
    try {
      const res = await fetch(path);
      return res.ok;
    } catch {
      return false;
    }
  };

  useEffect(() => {
    files.forEach(async (file) => {
      const exists = await checkFile(file);
      console.log(`${file}: ${exists ? '✅' : '❌'}`);
    });
  }, []);

  return (
    <div style={{padding: '20px'}}>
      <h2>File Status</h2>
      <ul>
        {files.map(file => (
          <li key={file}>
            {file}: <span id={`status-${file.replace(/\W/g, '-')}`}>Checking...</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

// Add to your main App component
<FileStatusChecker />

export default App;