import pandas as pd

flood_data = pd.read_csv("data/raw/floods.csv")
flood_data.to_parquet("data/processed/flood_risk.parquet")  # Faster reads