from transformers import pipeline
import tweepy

class SocialMonitor:
    def __init__(self):
        self.nlp = pipeline("text-classification", model="bert-base-uncased")
        self.twitter = tweepy.Client(bearer_token="YOUR_TWITTER_TOKEN")

    def analyze_social_media(self, text: str):
        result = self.nlp(text)
        return {
            "disaster": result["label"],
            "confidence": result["score"]
        }